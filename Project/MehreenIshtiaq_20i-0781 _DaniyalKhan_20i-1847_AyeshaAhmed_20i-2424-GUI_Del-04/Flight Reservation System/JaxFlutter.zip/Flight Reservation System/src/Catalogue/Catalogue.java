package Catalogue;

public interface Catalogue {
	void add(Object o);
	void update(Object o);
	void delete(Object o);
	void search(Object o);
	void remove(Object o);

}
