package Model;

import User.Passenger;

public class Booking {
	String flightID;
	Seat seat;
	Passenger passenger;
	int fare;
	String bookingID;
	boolean isPaid;

	public void createBooking() {

	}

	public void getBooking() {

	}

	public void cancelBooking() {

	}

	public void GetBookingDescription() {

	}
}
