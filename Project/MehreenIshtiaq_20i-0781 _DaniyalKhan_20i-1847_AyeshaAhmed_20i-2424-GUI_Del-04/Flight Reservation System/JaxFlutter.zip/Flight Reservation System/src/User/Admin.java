package User;

public class Admin extends User {

	public Admin(String username, int userId) {
		super(username, userId);
		// TODO Auto-generated constructor stub
	}

}
