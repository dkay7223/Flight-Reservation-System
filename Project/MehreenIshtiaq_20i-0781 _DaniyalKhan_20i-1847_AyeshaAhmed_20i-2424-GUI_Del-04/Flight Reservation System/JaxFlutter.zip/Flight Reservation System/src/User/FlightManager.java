package User;

public class FlightManager extends User {

	public FlightManager(String username, int userId) {
		super(username, userId);
		// TODO Auto-generated constructor stub
	}

}
