package Exceptions;

public class FlightAlreadyExistsException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5162429350555726188L;

	public FlightAlreadyExistsException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FlightAlreadyExistsException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public FlightAlreadyExistsException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public FlightAlreadyExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public FlightAlreadyExistsException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	

}
