package Exceptions;

public class RouteAlreadyExistsExcetion extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6619794572986775413L;

	public RouteAlreadyExistsExcetion() {
		super();
		// TODO Auto-generated constructor stub
	}

	public RouteAlreadyExistsExcetion(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public RouteAlreadyExistsExcetion(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public RouteAlreadyExistsExcetion(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public RouteAlreadyExistsExcetion(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
	
}
