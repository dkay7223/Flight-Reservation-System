package Exceptions;
public class NullValueException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8124854187951441629L;

	public NullValueException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NullValueException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public NullValueException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public NullValueException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public NullValueException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	

}
